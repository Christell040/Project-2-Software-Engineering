# Auth-with-Flutter-and-Firebase
Authentication pages I made with Flutter and Firebase

# Overview
This email and password authentication is implemented with many functionalities like, fluttertoast library, cloud firestore. In this tutorial, we have also implemented the Form validation for your email and password fields. 

# Requirements

• Replace android/app/google-services.json <br>
• Any Operating System (ie. MacOS X, Linux, Windows) <br>
• Any IDE with Flutter SDK installed (ie. IntelliJ, Android Studio, VSCode etc) <br>
• A little knowledge of Dart and Flutter <br>
• A brain to think 🤓🤓 <br>

## 
![Screenshot 2022-01-16 150702](https://user-images.githubusercontent.com/86530457/149657453-78806479-528d-457f-8039-77d086f37835.png),![Screenshot 2022-01-16 150725](https://user-images.githubusercontent.com/86530457/149657466-0805b72c-33e0-489d-a1f1-019873f8e1ac.png)

 
 
 
Happy Working 👍

<br>
 

[![GitHub stars](https://img.shields.io/github/stars/saidMirzayev0/TestApp.svg?style=social&label=Star)](https://github.com/saidMirzayev0/TestApp) [![GitHub forks](https://img.shields.io/github/forks/saidMirzayev0/TestApp.svg?style=social&label=Fork)](https://github.com/saidMirzayev0/TestApp/fork) [![GitHub watchers](https://img.shields.io/github/watchers/saidMirzayev0/TestApp.svg?style=social&label=Watch)](https://github.com/saidMirzayev0/TestApp) [![GitHub followers](https://img.shields.io/github/followers/saidMirzayev0.svg?style=social&label=Follow)](https://github.com/saidMirzayev0/TestApp)


<h3>Stay Healthy!✨Stay Safe!🖖</h3>
 

## Note
 I do not own any of the images used in this project.

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.



