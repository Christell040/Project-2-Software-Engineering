package com.example.email_password_login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
